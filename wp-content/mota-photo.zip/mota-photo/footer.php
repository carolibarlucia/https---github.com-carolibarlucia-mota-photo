<footer>
    <?php

    wp_nav_menu([
        'theme_location' => 'footer-menu',
      
       
    ])
    ?>
</footer>

</body>

</html>