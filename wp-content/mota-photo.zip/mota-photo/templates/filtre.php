<section class="menu-taxonomy">
	<div class="taxonomy">
		<form method="get" action="">
			<select name="categorie" id="categorie">
				<option value="0">CATEGORIE</option>
				<option value="reception">Réception</option>
				<option value="television">Télévision</option>
				<option value="concert">Concert</option>
				<option value="mariage">Mariage</option>
				
			</select>
		</form>

		<form method="get" action="">
			<select name="format" id="format">
				<option value="0">FORMAT</option>
				<option value="portrait">Portrait</option>
				<option value="paysage">Paysage</option>

			</select>
		</form>
	</div>
	<div class="taxonomy">
		<form method="get" action="">
			<select name="date" id="date">
				<option value="0">TRIER PAR</option>
				<option value="desc">date des plus récentes aux plus anciennes</option>
				<option value="asc">date des plus anciennes aux plus récentes</option>
			</select>
		</form>
	</div>
</section>