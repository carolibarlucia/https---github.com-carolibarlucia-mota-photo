<!-- Affichage photos -->
<div class="cptcontent-photo">
	<?php
	
	the_content();
	
	
$post_id = get_the_ID();
$url = get_template_directory_uri() . "/single_photo.php?id=" . $post_id; ?>

<a id="eye" class="eye-btn eye-btn-1" href="<?php the_permalink() ?>">;
<img class="eyes" src="<?php echo get_template_directory_uri() ?>/images/Icon_eye.png" />;
</a>;


</div>

