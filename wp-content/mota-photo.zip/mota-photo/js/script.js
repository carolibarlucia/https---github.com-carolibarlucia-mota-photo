var jq = jQuery.noConflict();
// Utilisez jq au lieu de $ à partir de ce point
jq(document).ready(function () {
  let apiUrl = "";
  let btnLoadMore = document.getElementById("load_more");
  if (btnLoadMore) {
    apiUrl = btnLoadMore.getAttribute("data-ajaxurl");
  }

  var contactModal = document.getElementById("contactModal");
  var btnContact = document.querySelectorAll(".idcontact");
  var contactLink = document.querySelector(".idcontact a");
  let lightboxes = document.querySelectorAll(".wp-lightbox-container");
  let btnFullscreen = document.querySelectorAll(".wp-block-image");
  let btnCloseFullscreen = document.querySelectorAll(".close-button");
  let openLightBoxBtn = document.querySelectorAll(".lightbox-trigger");
  let closeLightBoxBtn = document.querySelector(".lightbox__close");
  var lightboximg = document.getElementById("lightboxes");
  let currentLightboxIndex = 0;
  let lightboximage = document.getElementById("lightboximage");
  let next = document.querySelector(".lightbox__next");
  let previous = document.querySelector(".lightbox__prev");
  let index = 0;
  let info = document.getElementById("info");
  let cptcontent = document.querySelectorAll("cptcontent-photo");
  let photoContact = document.querySelector(".btn-contact");

  // Apparition / fermeture modale contact
  btnContact.forEach(function (e) {
    e.addEventListener('click', function() {
      console.log("click")
    displayForm();
    e.stopPropagation;
  })
  });

  document.onclick = function (event) {
    if (
      !contactModal.contains(event.target) &&
      contactModal.classList.contains("show") &&
      event.target != contactLink
    ) {
      hideForm();
    }
  };

  function displayForm() {
    if (contactModal.classList.contains("hidden")) {
      contactModal.classList.remove("hidden");
      contactModal.classList.add("show");
    }
  }

  function hideForm() {
    if (contactModal.classList.contains("show")) {
      contactModal.classList.remove("show");
      contactModal.classList.add("hidden");
    }
  }

 

  // LIGHTBOX

// Fonction pour initialiser les gestionnaires d'événements de la lightbox
function initializeLightbox() {
  jq(document).on("click", ".lightbox-trigger", function() {
    open(jq(this).data("index"));
  });

  jq(document).on("click", ".lightbox__close", function() {
    close();
  });

  jq(document).on("click", ".lightbox__next", function() {
    slideNext();
  });

  jq(document).on("click", ".lightbox__prev", function() {
    slidePrevious();
  });
}


jq(document).ready(function () {
  // Votre code existant...

  // Appeler la fonction pour initialiser les gestionnaires d'événements de la lightbox au chargement de la page
  initializeLightbox();
});

  
  function open(i) {
    jq.ajax({
      type: "POST",
      url: apiUrl,
      data: {
        action: "lightboxShow",
        index: i,
      },

      success: function (resp) {
        console.log(resp[index]);
        lightboxes = resp;
        index = i;
        setLightboxInfo();
      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.error("Erreur AJAX: " + textStatus, errorThrown);
        // Gérer l'erreur en conséquence
      },
    });
    lightboximg.classList.remove("lightboxHidden");
    lightboximg.classList.add("lightbox");
    console.log(index);
  }

  function close() {
    lightboximg.classList.remove("lightbox");
    lightboximg.classList.add("lightboxHidden");
  }

  openLightBoxBtn.forEach((e, i) => {
    e.addEventListener("click", function () {
      open(i);
    });
  });

  if (closeLightBoxBtn) {
    closeLightBoxBtn.addEventListener("click", function () {
      close();
    });
  }

  function slideNext() {
    if (index == lightboxes.length - 1) {
      index = 0;
    } else {
      index++;
    }
    setLightboxInfo();
  }
  function slidePrevious() {
    if (index == 0) {
      index = lightboxes.length - 1;
    } else {
      index--;
    }
    setLightboxInfo();
  }

  function setLightboxInfo() {
    const imageData = lightboxes[index];
    lightboximage.setAttribute("src", imageData.thumbnail);
    console.log(index);
  }

  next.addEventListener("click", function () {
    slideNext();
  });

  previous.addEventListener("click", function () {
    slidePrevious();
  });
});
