<?php 
echo do_shortcode('[contact-form-7 id="86adaae" title="Contact_photo"]');
?>