<?php 
echo do_shortcode('[contact-form-7 id="d8ab158" title="Contact"]');
?>