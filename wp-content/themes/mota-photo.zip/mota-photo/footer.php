<footer>
    <?php
    get_template_part('templates/lightbox');
    
    wp_nav_menu([
        'theme_location' => 'footer-menu',


    ])
    ?>
</footer>

</body>

</html>